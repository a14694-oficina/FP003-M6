-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql300.infinityfree.com
-- Tempo de geração: 16-Abr-2026 às 10:25
-- Versão do servidor: 11.4.10-MariaDB
-- versão do PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `if0_40156182_db_infraestrutura`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `equipamentos`
--

CREATE TABLE `equipamentos` (
  `id_equipamento` int(11) NOT NULL,
  `tipo` varchar(100) NOT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `modelo` varchar(100) DEFAULT NULL,
  `endereco_ip` varchar(15) DEFAULT NULL,
  `id_sala` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `equipamentos`
--

INSERT INTO `equipamentos` (`id_equipamento`, `tipo`, `marca`, `modelo`, `endereco_ip`, `id_sala`) VALUES
(1, 'Servidor', 'Dell', 'PowerEdge R740', '192.168.1.10', 1),
(2, 'Switch', 'Cisco', 'Catalyst 2960', '192.168.1.1', 3),
(3, 'Router', 'TP-Link', 'Archer C7', '192.168.1.254', 2),
(4, 'Computador', 'HP', 'EliteDesk 800 G4', '192.168.2.100', 3),
(5, 'Monitor', 'Samsung', 'SyncMaster S24F350', NULL, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `intervencoes`
--

CREATE TABLE `intervencoes` (
  `id_intervencao` int(11) NOT NULL,
  `data_intervencao` datetime NOT NULL,
  `descricao` mediumtext DEFAULT NULL,
  `id_equipamento` int(11) NOT NULL,
  `id_tecnico` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `intervencoes`
--

INSERT INTO `intervencoes` (`id_intervencao`, `data_intervencao`, `descricao`, `id_equipamento`, `id_tecnico`) VALUES
(1, '2026-01-15 10:30:00', 'Substituição de disco rígido no servidor principal.', 1, 1),
(2, '2026-02-20 14:00:00', 'Configuração de nova VLAN no switch.', 2, 2),
(3, '2026-03-05 09:00:00', 'Atualização de firmware do router.', 3, 2),
(4, '2026-03-10 11:00:00', 'Instalação de software no computador do escritório.', 4, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `salas`
--

CREATE TABLE `salas` (
  `id_sala` int(11) NOT NULL,
  `nome_sala` varchar(100) NOT NULL,
  `localizacao` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `salas`
--

INSERT INTO `salas` (`id_sala`, `nome_sala`, `localizacao`) VALUES
(1, 'Sala de GPSI', 'Edifício INA, Piso 4'),
(2, 'Sala de Multimédia', 'Edifício INA, Piso 4'),
(3, 'Sala de Redes', 'Edifício INA, Piso 4'),
(4, 'Sala de Programação', 'Edifício INA, Piso 4'),
(5, 'Sala de 3D', 'Edifício INA, Piso 4'),
(6, 'Sala de Comunicação', 'Edifício INA, Piso 4'),
(7, 'Sala de Audiovisuais', 'Edifício INA, Piso 4');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tecnicos`
--

CREATE TABLE `tecnicos` (
  `id_tecnico` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contacto` varchar(15) DEFAULT NULL,
  `utilizador` varchar(50) NOT NULL,
  `tipo` varchar(20) NOT NULL DEFAULT 'tecnico'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `tecnicos`
--

INSERT INTO `tecnicos` (`id_tecnico`, `nome`, `email`, `contacto`, `utilizador`, `tipo`) VALUES
(1, 'Administrador', 'admin@escola.pt', '912345678', 'admin', 'admin'),
(2, 'Alberto Ribeiro', 'alberto@escola.pt', '912345679', 'albertoribeiro', 'tecnico'),
(3, 'Jose Campos', 'jose@escola.pt', '912345680', 'josecampos', 'tecnico');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizadores`
--

CREATE TABLE `utilizadores` (
  `id_utilizador` int(11) NOT NULL,
  `utilizador` varchar(100) NOT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `utilizadores`
--

INSERT INTO `utilizadores` (`id_utilizador`, `utilizador`, `password`) VALUES
(1, 'admin', 'admin123'),
(2, 'albertoribeiro', 'albertoribeiro123'),
(3, 'josecampos', 'josecampos123');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `equipamentos`
--
ALTER TABLE `equipamentos`
  ADD PRIMARY KEY (`id_equipamento`),
  ADD UNIQUE KEY `endereco_ip` (`endereco_ip`),
  ADD KEY `id_sala` (`id_sala`);

--
-- Índices para tabela `intervencoes`
--
ALTER TABLE `intervencoes`
  ADD PRIMARY KEY (`id_intervencao`),
  ADD KEY `id_equipamento` (`id_equipamento`),
  ADD KEY `id_tecnico` (`id_tecnico`);

--
-- Índices para tabela `salas`
--
ALTER TABLE `salas`
  ADD PRIMARY KEY (`id_sala`);

--
-- Índices para tabela `tecnicos`
--
ALTER TABLE `tecnicos`
  ADD PRIMARY KEY (`id_tecnico`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `utilizador` (`utilizador`);

--
-- Índices para tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  ADD PRIMARY KEY (`id_utilizador`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `equipamentos`
--
ALTER TABLE `equipamentos`
  MODIFY `id_equipamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `intervencoes`
--
ALTER TABLE `intervencoes`
  MODIFY `id_intervencao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `salas`
--
ALTER TABLE `salas`
  MODIFY `id_sala` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tecnicos`
--
ALTER TABLE `tecnicos`
  MODIFY `id_tecnico` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  MODIFY `id_utilizador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
